package com.example.forteachersapp

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase



class MainActivity : AppCompatActivity() {

    private lateinit var t1: EditText
    private lateinit var t2: EditText
    private lateinit var t3: EditText
    private lateinit var t4: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        t1 = findViewById(R.id.t1)
        t2 = findViewById(R.id.t2)
        t3 = findViewById(R.id.t3)
        t4 = findViewById(R.id.t4)
    }

    fun process(view: View) {
        val roll = t1.text.toString().trim()
        val name = t2.text.toString().trim()
        val course = t3.text.toString().trim()
        val duration = t4.text.toString().trim()

        val obj = dataholder(name, course, duration)

        val db = FirebaseDatabase.getInstance()
        val node = db.getReference("students").child(roll) // Use child(roll) to create a unique node

        node.setValue(obj).addOnCompleteListener {
            if (it.isSuccessful) {
                Toast.makeText(applicationContext, "Value Inserted", Toast.LENGTH_LONG).show()
                t1.setText("")
                t2.setText("")
                t3.setText("")
                t4.setText("")
            } else {
                Toast.makeText(applicationContext, "Error: ${it.exception?.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
